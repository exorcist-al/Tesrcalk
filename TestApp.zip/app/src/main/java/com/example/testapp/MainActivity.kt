package com.example.testapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.testapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var current = ""
        var operator = ""
        var firstNumber = 0.0

        val buttons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )

        for (b in buttons) {
            b.setOnClickListener {
                current += b.text
                binding.resultView.text = current
            }
        }

        val ops = mapOf(
            binding.btnAdd to "+",
            binding.btnSub to "-",
            binding.btnMul to "*",
            binding.btnDiv to "/"
        )

        for ((btn, op) in ops) {
            btn.setOnClickListener {
                if (current.isNotEmpty()) {
                    firstNumber = current.toDouble()
                    operator = op
                    current = ""
                    binding.resultView.text = operator
                }
            }
        }

        binding.btnClear.setOnClickListener {
            current = ""
            operator = ""
            firstNumber = 0.0
            binding.resultView.text = "0"
        }

        binding.btnEqual.setOnClickListener {
            if (current.isNotEmpty()) {
                val secondNumber = current.toDouble()
                val result = when (operator) {
                    "+" -> firstNumber + secondNumber
                    "-" -> firstNumber - secondNumber
                    "*" -> firstNumber * secondNumber
                    "/" -> if (secondNumber != 0.0) firstNumber / secondNumber else Double.NaN
                    else -> 0.0
                }
                binding.resultView.text = result.toString()
                current = result.toString()
            }
        }
    }
}
